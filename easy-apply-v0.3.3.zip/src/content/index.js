(function(){"use strict";document.documentElement.setAttribute("data-easy-apply-ext",chrome.runtime.getManifest().version)})();
